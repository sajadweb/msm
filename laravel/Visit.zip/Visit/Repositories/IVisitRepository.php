<?php
namespace Services\Visit\Repositories;

use Services\Visit\Models\Visit;
use App\Repository\IRepository;

/**
 * Visit
 * @author Sajadweb
 * Fri Dec 25 2020 02:43:12 GMT+0330 (Iran Standard Time)
 */
interface IVisitRepository extends IRepository
{
}