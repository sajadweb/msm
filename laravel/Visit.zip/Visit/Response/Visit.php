<?php

namespace Services\Visit\Response;

/**
 * @OA\Schema(
 *     title="Visit",
 *     description="Visit",
 *     type="object"
 * )
 */
class Visit
{

}