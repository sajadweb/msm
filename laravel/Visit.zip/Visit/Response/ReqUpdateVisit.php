<?php

namespace Services\Visit\Response;

/**
 * @OA\Schema(
 *     title="ReqUpdateVisit",
 *     description="ReqUpdateVisit",
 *     type="object"
 * )
 */
class ReqUpdateVisit
{

}