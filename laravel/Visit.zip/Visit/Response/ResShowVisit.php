<?php

namespace Services\Visit\Response;

/**
 * @OA\Schema(
 *     title="ResShowVisit",
 *     description="ResShowVisit",
 *     type="object"
 * )
 */
class ResShowVisit
{

}