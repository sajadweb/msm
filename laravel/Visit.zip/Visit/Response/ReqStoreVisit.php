<?php

namespace Services\Visit\Response;

/**
 * @OA\Schema(
 *     title="ReqStoreVisit",
 *     description="ReqStoreVisit",
 *     type="object"
 * )
 */
class ReqStoreVisit
{

}