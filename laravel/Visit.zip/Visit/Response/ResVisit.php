<?php

namespace Services\Visit\Response;

/**
 * @OA\Schema(
 *     title="ResVisit",
 *     description="ResVisit",
 *     type="object"
 * )
 */
class ResVisit
{

}