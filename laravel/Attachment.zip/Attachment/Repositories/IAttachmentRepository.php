<?php
namespace Services\Attachment\Repositories;

use App\Repository\IRepository;

/**
 * Category
 * @author Sajadweb
 * Fri Dec 25 2020 02:37:20 GMT+0330 (Iran Standard Time)
 */
interface IAttachmentRepository extends IRepository
{
}
