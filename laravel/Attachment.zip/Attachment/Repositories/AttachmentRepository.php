<?php

namespace Services\Attachment\Repositories;

use Services\Attachment\Models\Attachment;
use App\Repository\Repository;

/**
 * Category
 * @author Sajadweb
 * Fri Dec 25 2020 02:37:20 GMT+0330 (Iran Standard Time)
 */
class AttachmentRepository extends Repository implements IAttachmentRepository
{
    /**
     * The model being queried.
     *
     * @var Attachment
     */
    public $model;

    public function __construct(Attachment $model)
    {
        $this->model = new $model();
    }

    public function destroy($uuid)
    {
        try {
            return $this->model->
            where([
                'user' => auth()->user()->id,
                'uuid' => $uuid
            ])->delete();
        } catch (\Exception $exp) {
            dd($exp);
            return false;
        }
    }

}
