<?php


namespace Services\Attachment\Enum;


abstract class AttachmentType
{

    public static $IMAGE = 'image';
    public static $FILE = 'file';
}
