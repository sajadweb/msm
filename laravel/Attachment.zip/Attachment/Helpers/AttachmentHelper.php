<?php
// Attachment helper
function attachMap($attachments)
{
    if (!$attachments) return null;
    return collect($attachments)->map(function ($item) {
        return [
            "path" => getBaseUri($item->path),
            "uuid" => $item->uuid,
        ];
    })->all();
}
