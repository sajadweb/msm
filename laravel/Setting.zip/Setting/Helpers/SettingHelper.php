<?php
// Setting helper
function helperSetting(){
  return "Setting";
}