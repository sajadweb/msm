<?php

namespace Services\Setting\Response;

/**
 * @OA\Schema(
 *     title="ResSetting",
 *     description="ResSetting",
 *     type="object"
 * )
 */
class ResSetting extends Setting
{

}
