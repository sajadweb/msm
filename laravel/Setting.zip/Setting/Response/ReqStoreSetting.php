<?php

namespace Services\Setting\Response;

/**
 * @OA\Schema(
 *     title="ReqStoreSetting",
 *     description="ReqStoreSetting",
 *     type="object"
 * )
 */
class ReqStoreSetting  extends Setting
{

}
