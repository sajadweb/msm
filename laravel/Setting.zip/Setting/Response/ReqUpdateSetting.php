<?php

namespace Services\Setting\Response;

/**
 * @OA\Schema(
 *     title="ReqUpdateSetting",
 *     description="ReqUpdateSetting",
 *     type="object"
 * )
 */
class ReqUpdateSetting  extends Setting
{

}
