<?php

namespace Services\Setting\Response;

/**
 * @OA\Schema(
 *     title="ResShowSetting",
 *     description="ResShowSetting",
 *     type="object"
 * )
 */
class ResShowSetting extends Setting
{

}
