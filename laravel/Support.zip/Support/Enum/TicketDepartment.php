<?php


namespace Services\Support\Enum;


abstract class TicketDepartment
{
    const General = 0;
    const Finance = 1;
    const Events = 2;
    const Corporations = 3;
    const Managers = 4;
}
