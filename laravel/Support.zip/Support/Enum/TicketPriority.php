<?php


namespace Services\Support\Enum;


abstract class TicketPriority
{
    const Normal = 0;
    const NonSignificant = 1;
    const Important = 2;
}
