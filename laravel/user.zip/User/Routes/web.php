<?php
use Illuminate\Support\Facades\Route;
//// Authentication
Route::group(['prefix' => 'auth'], function(){
    Route::get('/login', 'WebController@login')->name('login');
    Route::post('/login', 'WebController@verify')->name('verify');
    Route::post('/verify', 'WebController@verified')->name('verified');
    Route::get('/register', 'WebController@register')->name('register');
    Route::get('/logout', 'WebController@logout')->name('logout');
    Route::get('/social', 'WebController@redirect')->name('social.redirect');
    Route::get('/callback', 'WebController@callback')->name('social.callback');
});
