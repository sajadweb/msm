<?php


function getBaseUri(?string $uri = null)
{
    if ($uri === null)
        return null;
    else
        return \Illuminate\Support\Facades\Storage::url($uri);
}

function makeUsername(string $username)
{
    return "https://uin.vet/u/$username";;
}

function uploadPath($path)
{
    try {
        if ($path === null) {
            return null;
        }
        $date = date('Y-m');
        return $date . "/" . $path;
    } catch (\Exception $e) {
        return null;
    }
}

function notify(string $let)
{
    \Bugsnag\BugsnagLaravel\Facades\Bugsnag::notifyException(new RuntimeException($let));
}


function notifyException(\Exception $ex)
{
    \Bugsnag\BugsnagLaravel\Facades\Bugsnag::notifyException($ex);
}

function slack(string $message)
{
    Illuminate\Support\Facades\Log::critical($message);
}

function mapper($class, $data, $fun)
{

    $array = get_object_vars($class);
    $res = [];
    foreach ($array as $key => $value) {
        try {
            $res[$key] = $data->{$key} ?? null;
        } catch (Exception $e) {
            $res[$key] = null;
        }
    }
    if ($fun)
        return $fun($res);
    else
        return $res;
}

function userMap($user)
{
    if (!$user) return null;
    return [
        'uuid' => $user->uuid,
        'name' => $user->name,
        'avatar' => getBaseUri($user->avatar),
    ];
}
