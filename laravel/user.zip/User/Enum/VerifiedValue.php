<?php


namespace Services\User\Enum;


abstract class VerifiedValue
{
    const SUCCESS = 'success';
    const  PENDING = 'pending';
    const  FAILURE = 'failure';
}
