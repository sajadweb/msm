<?php


namespace Services\User\Controllers;


use App\Enums\SMSTemplate;
use App\Enums\SMSType;
use App\Jobs\SendSMS;
use App\Models\User;
use Exception;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Laravel\Socialite\Facades\Socialite;
use function auth;
use function view;

class WebController
{
    public function login(){
        try{
            return view('views::login');
        }catch (Exception $e){
            return view('error');
        }
    }

    /**
     * @param Request $request
     * @return Application|Factory|View|RedirectResponse
     */
    public function verify(Request $request)
    {
        try {
            $mobile = $this->checkZeroFirst($request->input('mobile'));
            $captain=null;
            if ($request->has("captain")){
                $captain = User::where(["username"=>$request->input("captain")])->first();
                if ($captain != null){
                    $captain=$captain['id'];
                }
            }

            $code = random_int(1000, 999999);
            $existingUser = User::where('mobile', $mobile)->first();
            if ($existingUser === null){
                User::create([
                    'mobile' => $mobile,
                    'code' => $code,
                    'name' => $request->input('name'),
                    'captain' => $captain,
                    "username" => Str::random(6),
                    'code_expire'=>now()->addMinutes(2)
                ]);
            }else{
                User::where('mobile', $mobile)->update(['code' => $code, 'code_expire'=>now()->addMinutes(2)]);
            }
            if ($request->has('captain')) {
                User::where('username', $captain)->increment('team');
            }
            SendSMS::dispatch(SMSType::AUTH, $mobile, $code, SMSTemplate::VERIFY);
            return view('views::verify', compact('mobile'));
        } catch (Exception $e) {
            return back()->withInput()->withErrors(['error' => 'credentials']);
        }
    }

    /**
     * @param Request $request
     */
    public function verified(Request $request)
    {
        try {
            $mobile = $this->checkZeroFirst($request->input('mobile'));
            $code = $request->input('code');
            $user = User::where([
                'mobile' => $mobile,
                'code' => $code,
            ])->where('code_expire','>=',now())->first();
            if ($user == null) {
                return back()->withInput()->withErrors(['error' => 'credentials']);
            }
            auth()->guard('web')->loginUsingId($user['id'], true);
            return redirect()->route('dashboard');
        } catch (Exception $e) {
            return back()->withInput()->withErrors(['error' => 'credentials']);
        }
    }

    function checkZeroFirst($string){
        if($string[0]==='0')
        {
            return substr($string,1);
        }
        return $string;
    }

    /**
     * @return RedirectResponse|void
     */
    public function logout()
    {
        try {
            auth()->guard('web')->logout();
            return redirect()->route('index');
        } catch (Exception $e) {
            return abort(500);
        }
    }

    /**
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|void
     */
    public function redirect(){
        try{
            return Socialite::driver('google')->redirect();
        }catch (Exception $e){
            return abort(500);
        }
    }

    /**
     * @return RedirectResponse|void
     */
    public function callback()
    {
        try {
            $user = Socialite::driver('google')->user();
            $usr = User::where('email', $user->getEmail())->first();
            if ($usr === null) {
                $usr = User::create([
                    'first_name' => $user->getName(),
                    'email' => $user->getEmail()
                ]);
            }
            auth()->guard('web')->loginUsingId($usr['id']);
            return redirect()->route('dashboard');
        } catch (Exception $e) {
            return abort(500);
        }
    }

}
